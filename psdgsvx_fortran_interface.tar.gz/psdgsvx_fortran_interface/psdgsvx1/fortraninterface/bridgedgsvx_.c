#include "slu_mt_ddefs.h"
void pdlinsolx(int_t m , int_t n , int_t nnz ,double *xact,SuperMatrix A,int_t nprocs);
void bridgedgsvx_(int_t *fm,int_t *fn,int_t *fnnz,double *a ,int_t *asub,int_t *xa,double *xact,int_t *fnprocs){
int_t m= *fm;
int_t n= *fn;
int_t nnz= *fnnz;
int_t nprocs= *fnprocs;
SuperMatrix A;
int_t nrhs=1;

    for (int i = 0; i < nnz; ++i) --asub[i];
    for (int i = 0; i <= n; ++i) --xa[i];
int_t i;
printf ("m=%d;\n",m);
printf ("n=%d;\n",n);
printf ("nnz=%d;\n",nnz);
//for (i=0;i<nnz;i++) printf("a(%d)=%lf\n",i,a[i]);
//for (i=0;i<nnz;i++) printf("asub(%d)=%d\n",i,asub[i]);
//for (i=0;i<n+1;i++) printf("xa(%d)=%d\n",i,xa[i]);
//for (i=0;i<n;i++) printf("xact[%d]=%lf;\n",i,xact[i]);
dCreate_CompCol_Matrix(&A, m, n, nnz, a, asub, xa, SLU_NC, SLU_D, SLU_GE);
pdlinsolx( m ,  n ,  nnz , xact,A,nprocs);
//for (i=0;i<n;i++) printf("xact[%d]=%lf\t\n",i,xact[i]);
    for (int i = 0; i < nnz; ++i) ++asub[i];
    for (int i = 0; i <= n; ++i) ++xa[i];
	//SUPERLU_FREE (xact);
        Destroy_CompCol_Matrix(&A);
}
