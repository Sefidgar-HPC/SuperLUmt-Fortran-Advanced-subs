psdgsvx=Genral form

psdgsvx1= This example illustrates how to use PDGSSVX to solve systems repeatedly with the same sparsity pattern of matrix A.


psdgsvx2=This example illustrates how to use PDGSSVX to solve systems repeatedly with symmetric mode

Please send your valuable feedbak to

Seyed mohamad hassan sefidgar
"hasan.mamad1370.mh@gmail.com"

Ali rahmani Firoozjaee
"rahmani@nit.ac.ir"
 
